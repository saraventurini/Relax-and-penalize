clearvars;
close all;

addpath '.\_functions'
addpath '.\_ext'
addpath '.\_functions\_optim'
addpath '.\_functions\_aux'
addpath '.\_functions\_hypergradient'

digitsOld = digits(100);

u_list = {{500,'equal'},{200,'equal'},{500,'inequal'},{200,'inequal'},{500,'rand'}};

for u = u_list

%\\\\\ Synthesis parameters
N                           = 20;          %Number of samples
P                           = 100;         %Number of features
T                           = u{1}{1}; %500;         %Number of tasks
L                           = 10;          %Number of groups
S                           = 1;           %Number of non-zero groups per task

synth.groups.distrib        = u{1}{2};  %Group size ('equal' or 'rand' or 'inequal')
synth.noise.param           = [0 .2]; 


a_list = [0.1,0.2,0.3,0.4,0.5,0.6];
for a = a_list
    synth.features.a     = a; 

    %\\\\\ Bilevel Parameters
    EPS                         = 10^(-3);  
    
    %\\\\\ Bilevel Parameters
    % - Inner problem
    param.inner.itermax         = 500;
    param.inner.compObjective   = false;
    % - Outer problem
    param.outer.compObjective   = false;         %Compute objective at each iteration
    param.outer.iter_of   = 0;      %Compute objective at each iter_of iterations
    param.outer.savenormGroupOperator = false;    %save value norm operator
    param.outer.saveHyperGrad   = false;         % MODIFIED Save hypergradient at each iteration
    param.outer.saveLambda   = true;            % MODIFIED Save lambda at each iteration
    param.outer.saveTheta  = false;         %Save theta at each iteration
    param.outer.saveTheta_dist = false;  %Save Frobenius norm theta_star - theta at each iteration
    param.outer.fixedPointHG    = false;        %Accelerated scheme for computing the hypergradient
    param.outer.projection      = 'simplex';    %Space Theta (see also, 'posSphere' and 'box')
    param.outer.projection_lambda      = 'box';    %Space Lambda %MODIFIED
    param.outer.itermax         =  [5000 5000 2500 2500 2500 2500];

    param.outer.nGroups         = L;            %Number of groups
    param.outer.batchSize       = 1;            %Batch size for stochastic optimization (see below) 
    param.outer.optimizer       = 'SAGA';       %Outer optimizer (see also, 'GD', 'SGD' and 'SAGD' and 'SAGA')
    param.outer.displayOnline   = false;        %Online display of groups
    
    param.outer.itermax_k         = 10;         %Number of outer iterations epsilon
    param.outer.eps_k     = 1e5;                 %initialization value epsilon parameter penalty term 
    e_min = 1e-2;
    param.outer.beta = nthroot(e_min/ param.outer.eps_k,param.outer.itermax_k);        %decreasing factor epsilon %chosen s.t. e_itermax = 10^(-3)
    
    folder_name_ = "Results_synthesizeDataset";
    folder_name = '../synthesizeDataset';
    sampl = 10; %samples %number of synthetic datasets same parameters
    for i=5:sampl
 
        %% SYNTHESIS 
        file_name="synth_dataset_N"+num2str(N)+"_P"+num2str(P)+"_T"+num2str(T)+"_L"+num2str(L)+"_S"+num2str(S)+"_DIST"+synth.groups.distrib+"_NOISE"+num2str(synth.noise.param(2))+"_a"+num2str(synth.features.a)+"_"+num2str(i)+'.mat';
        file_name = fullfile(folder_name,file_name); 
        load(file_name) %save(file_name,'N','P','T','L','S','synth','y','X','thetastar','wstar','Xwstar')
    
        figure(101);clf;
        subplot(121);
        imagesc(thetastar);
        xlabel('Groups','Interpreter','latex','fontsize',2)
        ylabel('Features','Interpreter','latex','fontsize',2)
        title('Oracle $\theta^*$','Interpreter','latex','fontsize',2)
        set(gca,'fontsize',15,'clim',[0 1])
        colorbar;
        colormap(parula);
        c=subplot(122);
        wlim = max([abs(min(min(wstar))),abs(max(max(wstar)))]);
        imagesc(wstar);
        colorbar;
        colormap(parula);
        xlabel('Tasks','Interpreter','latex','fontsize',2)
        ylabel('Features','Interpreter','latex','fontsize',2)
        title('Oracle $w^*$','Interpreter','latex','fontsize',2)
        set(gca,'fontsize',15,'CLim',[-wlim wlim])
    
        %% ANALYSIS
    
        %from cell to matrix
        y.trn = cell2mat(y.trn); 
        y.val = cell2mat(y.val);
        y.tst = cell2mat(y.tst);
        X.trn = cat(3,X.trn{:}); 
        X.val = cat(3,X.val{:});
        X.tst = cat(3,X.tst{:});
        
        [thetaHat,lambdaHat,it_cond,eps_k,otp] = BiGLasso_penalty_lambda( y,X,EPS,param, thetastar); %MODIFIED
        
        %plot oracle solution
        figure(101);clf;
        subplot(121);
        imagesc(thetastar);
        xlabel('Groups','Interpreter','latex','fontsize',2)
        ylabel('Features','Interpreter','latex','fontsize',2)
        title('Oracle $\theta^*$','Interpreter','latex','fontsize',2)
        set(gca,'fontsize',15,'clim',[0 1])
        subplot(122);
        imagesc(thetaHat);
        xlabel('Groups','Interpreter','latex','fontsize',2)
        ylabel('Features','Interpreter','latex','fontsize',2)
        title('$\hat{\theta}$','Interpreter','latex','fontsize',2)
        set(gca,'fontsize',15,'clim',[0 1])

        %save plots
        file_name = "plot_result_penalty_synth_dataset_N"+num2str(N)+"_P"+num2str(P)+"_T"+num2str(T)+"_L"+num2str(L)+"_S"+num2str(S)+"_DIST"+synth.groups.distrib+"_NOISE"+num2str(synth.noise.param(2))+"_a"+num2str(synth.features.a)+"_"+num2str(i)+".png";
        file_name = fullfile(folder_name_,file_name); 
        saveas(gca,file_name)
    
        %save results 
        file_name = "penalty_lambda_result_synth_dataset_N"+num2str(N)+"_P"+num2str(P)+"_T"+num2str(T)+"_L"+num2str(L)+"_S"+num2str(S)+"_DIST"+synth.groups.distrib+"_NOISE"+num2str(synth.noise.param(2))+"_a"+num2str(synth.features.a)+"_"+num2str(i)+'.mat';
        file_name = fullfile(folder_name_,file_name); 
        save(file_name,'thetaHat','lambdaHat','it_cond','eps_k','param','otp') %MODIFIED
    
    end
end
end

