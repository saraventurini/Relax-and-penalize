function [ opt_upper ] = optimBLGS_setting_penalty_lambda( opt_lower,param, param_inner) 

%% HEADER

if ~isfield(param.outer,'compObjective')
    param.outer.compObjective = false;
end

% - Optimizer & batch-size for stochastic descent
if strcmp(param.outer.optimizer,'GD')
    param.outer.batchSize = param.outer.nTasks;
elseif ~isfield(param.outer,'batchSize')
    param.outer.batchSize = 1;
    if ~isfield(param.outer,'optimizer')
        param.outer.optimizer   = 'SAGA';
    end
end

if ~isfield(param.outer,'projection')
    param.outer.projection = 'simplex';
end

if param.outer.linesearch
    if ~isfield(param.outer,'linesearch_c1')
        param.outer.linesearch_c1 = 0.1;
    end
    if ~isfield(param.outer,'linesearch_contraction')
        param.outer.linesearch_contraction = 0.8;
    end
end

%% - PROJECTION OF THE GROUP STRUCTURE ONTO THETA

switch param.outer.projection
    case 'simplex'
        proxl_v = @(varx) proj_unitSimplex(varx')';
    case 'posSphere'
        proxl_v = @(varx) proj_positiveUnitSphere(varx')';
    case 'box'
        proxl_v = @(varx) proj_1dset( varx', [0 1] )';
    otherwise
        disp('/!\ param.projection not well defined.')
        disp('either choose `simplex` or `positiveSphere`.')
end

proxl = @(varx) proxl_v(varx);

switch param.outer.projection_lambda
    case 'box'
        proxl_v_lambda = @(varx) proj_1dset( varx, [0.001 1] )'; 
    otherwise
        disp('/!\ param.projection not well defined.')
        disp('either choose `box`.')
end
proxl_lambda = @(varx) proxl_v_lambda(varx);

%% INITIALIZATION


    function [theta,hyperGrad_aux,lambda,hyperGrad_aux_lambda,plt] = optimBLGS_initialize()
        
        theta = proxl(  (1/param.inner.nGroups)*ones(param.inner.nFeatures,param.inner.nGroups) + .01*randn(param.inner.nFeatures,param.inner.nGroups) );
	    lambda = 0.1;        
	    plt   = optimBLGS_display_init(theta);
        
        
        switch param.outer.optimizer
            case 'GD'
                hyperGrad_aux.all   = NaN;
                hyperGrad_aux.mean  = NaN;
                hyperGrad_aux_lambda.all  = NaN; 
                hyperGrad_aux_lambda.mean  = NaN; 
            case 'SGD'
                hyperGrad_aux.all   = NaN;
                hyperGrad_aux.mean  = NaN;
                hyperGrad_aux_lambda.all  = NaN; 
                hyperGrad_aux_lambda.mean  = NaN; 
            case 'SAGD'
                hyperGrad_aux.all   = zeros(param.inner.nFeatures,param.inner.nGroups,param.inner.nTasks);
                hyperGrad_aux.mean  = NaN; 
                hyperGrad_aux_lambda.all   = zeros(1,param.inner.nTasks); 
                hyperGrad_aux_lambda.mean  = NaN; 
            case 'SAGA'
                hyperGrad_aux.all   = zeros(param.inner.nFeatures,param.inner.nGroups,param.inner.nTasks);
                hyperGrad_aux.mean  = zeros(param.inner.nFeatures,param.inner.nGroups);
                hyperGrad_aux_lambda.all   = zeros(1,param.inner.nTasks); 
                hyperGrad_aux_lambda.mean  = zeros(1); 
        end
        

        
    end



%% HYPERGRADIENT

    function [hyperGrad,hyperGrad_aux,hyperGrad_lambda,hyperGrad_aux_lambda,outerObj,nGO] = optimBLGS_hyperGradient(y,yval,X,Xval,theta,hyperGrad_aux,lambda,hyperGrad_aux_lambda,eps_k,iter,iter_of) 
        
        N_sample = size(y,1); %number of samples
        
        if ~param.outer.compObjective || (rem(iter-1,iter_of)~=0)
            outerObj = NaN;
        end
                
        % Partial Hypergradients on a Batch of Tasks
        if (param.outer.batchSize ~= param.inner.nTasks)
            batch = datasample(1:param.inner.nTasks,param.outer.batchSize,'Replace',false);

            if param.outer.compObjective && (rem(iter-1,iter_of)==0)
                [W,~,~] = optimGS_lower_penalty_lambda( y, X, theta, lambda, opt_lower, param.inner, iter ); 
            end   
            [~,var,nGO] = optimGS_lower_penalty_lambda( y(:,batch), X(:,:,batch), theta, lambda, opt_lower, param.inner, iter ); 
            
            [hyperGrad_batch,hyperGrad_batch_lambda]  = optimGS_hypergradient_v2_penalty_lambda(yval(:,batch),Xval(:,:,batch),theta,lambda, opt_lower, param,var); 
            hyperGrad_batch  = hyperGrad_batch + (1-2*theta)/eps_k; %add penalty term hradient to hypergradient         
        else
            [W,var,nGO] = optimGS_lower_penalty_lambda( y, X, theta, lambda, opt_lower, param.inner, iter ); 
 
            [hyperGrad_batch,hyperGrad_batch_lambda]  = optimGS_hypergradient_v2_penalty_lambda(yval,Xval,theta,lambda, opt_lower, param,var); 
            hyperGrad_batch  = hyperGrad_batch + (1-2*theta)/eps_k; %add penalty term hradient to hypergradient         
        end
        
        if param.outer.compObjective && (rem(iter-1,iter_of)==0)
            outerObj = opt_upper.objective(yval,Xval,W,theta,eps_k,param.inner.nTasks,N_sample);
        end
    
        switch param.outer.optimizer
            
            case 'GD'   %Gradient Descent (since batch size = T)
                hyperGrad_aux.all   = NaN;
                hyperGrad           = squeeze(mean(hyperGrad_batch,3));
                hyperGrad_aux.mean  = NaN;
                hyperGrad_aux_lambda.all   = NaN;  
                hyperGrad_lambda           = squeeze(mean(hyperGrad_batch_lambda,2));  
                hyperGrad_aux_lambda.mean  = NaN;  
                
            case 'SGD'  %Stochastic Gradient Descent
                hyperGrad_aux.all   = NaN;
                hyperGrad           = squeeze(mean(hyperGrad_batch,3));
                hyperGrad_aux.mean  = NaN;
                hyperGrad_aux_lambda.all   = NaN;  
                hyperGrad_lambda           = squeeze(mean(hyperGrad_batch_lambda,2));  
                hyperGrad_aux_lambda.mean  = NaN;  
                
            case 'SAGD' %Stochastic Averaged Gradient Descent

                if (param.outer.batchSize ~= param.inner.nTasks)
                    for xtt=1:length(batch)
                        hyperGrad_aux.all(:,:,batch(xtt)) = hyperGrad_batch(:,:,xtt);
                        hyperGrad_aux_lambda.all(:,batch(xtt))   = hyperGrad_batch_lambda(:,xtt);  
                    end
                    hyperGrad           = squeeze(mean(hyperGrad_aux.all,3));
                    hyperGrad_aux.mean  = NaN;
                    hyperGrad_lambda           = squeeze(mean(hyperGrad_aux_lambda.all,2)); 
                    hyperGrad_aux_lambda.mean  = NaN; 
                else
                    hyperGrad_aux.all= hyperGrad_batch;
                    hyperGrad_aux_lambda.all= hyperGrad_batch_lambda';
                    hyperGrad           = squeeze(mean(hyperGrad_aux.all,3));
                    hyperGrad_aux.mean  = NaN;
                    hyperGrad_lambda           = squeeze(mean(hyperGrad_aux_lambda.all,2)); 
                    hyperGrad_aux_lambda.mean  = NaN; 
                end

                
            case 'SAGA' %Stochastic Averaged Gradient Descent with Variance Reduction

                if (param.outer.batchSize ~= param.inner.nTasks)
                    hyperGrad_diff = NaN(param.inner.nFeatures,param.inner.nGroups,param.outer.batchSize);
                    hyperGrad_diff_lambda = NaN(1,param.outer.batchSize);
                    for xtt=1:length(batch)
                        hyperGrad_diff(:,:,xtt)             = hyperGrad_batch(:,:,xtt) - hyperGrad_aux.all(:,:,batch(xtt));
                        hyperGrad_aux.all(:,:,batch(xtt))   = hyperGrad_batch(:,:,xtt);
                        hyperGrad_diff_lambda(:,xtt)        = hyperGrad_batch_lambda(:,xtt) - hyperGrad_aux_lambda.all(:,batch(xtt)); 
                        hyperGrad_aux_lambda.all(:,batch(xtt))   = hyperGrad_batch_lambda(:,xtt);  
                    end
                    hyperGrad           = mean(hyperGrad_diff,3)    + hyperGrad_aux.mean;
                    hyperGrad_aux.mean  = sum(hyperGrad_diff,3)/param.inner.nTasks   + hyperGrad_aux.mean;  
                    hyperGrad_lambda           = mean(hyperGrad_diff_lambda,2)     + hyperGrad_aux_lambda.mean;  
                    hyperGrad_aux_lambda.mean  = mean(hyperGrad_diff_lambda,2)   + hyperGrad_aux_lambda.mean;   
                else
                    hyperGrad_diff            = hyperGrad_batch - hyperGrad_aux.all;
                    hyperGrad_aux.all   = hyperGrad_batch;
                    hyperGrad_diff_lambda        = hyperGrad_batch_lambda - hyperGrad_aux_lambda.all; 
                    hyperGrad_aux_lambda.all   = hyperGrad_batch_lambda;  
                    hyperGrad           = mean(hyperGrad_diff,3)    + hyperGrad_aux.mean;
                    hyperGrad_aux.mean  = sum(hyperGrad_diff,3)/param.inner.nTasks   + hyperGrad_aux.mean;  
                    hyperGrad_lambda           = mean(hyperGrad_diff_lambda,2)     + hyperGrad_aux_lambda.mean;  
                    hyperGrad_aux_lambda.mean  = mean(hyperGrad_diff_lambda,2)   + hyperGrad_aux_lambda.mean;   
                end
        end

    end


%% DISPLAY

    function [plt] = optimBLGS_display_init(theta)
        if param.outer.dispOnline
            
            Fig=figure;
            plt=imagesc(theta);
            title('Iterate $\theta$','Interpreter','latex','fontsize',13)
            ylabel('Features','Interpreter','latex','fontsize',2)
            xlabel('Group indices','Interpreter','latex','fontsize',2)
            set(gca,'fontsize',15,'clim',[0 1])
            xticks([1:param.outer.nGroups]);
            colormap(flipud(gray))
            refreshdata(Fig,'caller');
            drawnow;
              
        else
            plt = [];
        end
    end

    function [] = optimBLGS_display_refresh(plt,theta)
        if param.outer.dispOnline
            plt.CData = theta;
            refreshdata(plt,'caller');
            drawnow limitrate
        end
    end



%% OUTPUT

opt_upper           = struct('hypergradient',@optimBLGS_hyperGradient,'proj_Theta',proxl,'proj_Lambda',proxl_lambda,'initialize',@optimBLGS_initialize,'objective',@opt_lower.fidelity,'linesearch',@optimBLGS_linesearch); 
opt_upper.display   = struct('init',@optimBLGS_display_init,'refresh',@optimBLGS_display_refresh);



end

