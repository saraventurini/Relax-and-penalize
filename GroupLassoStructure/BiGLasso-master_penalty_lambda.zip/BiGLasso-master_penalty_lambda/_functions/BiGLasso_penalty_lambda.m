function [ theta,Lambda,it_cond,eps_k,otp ] = BiGLasso_penalty_lambda( y,X,EPS, param, thetastar) 

format long

rng(0)
iter_of = param.outer.iter_of; 

otp = struct;

if ~isfield(param,'misc')
    param.misc = struct;
end

if ~isfield(param.misc,'saveiter')
    param.misc.saveiter = Inf;
end

%% Header needed for upper-level problem

if ~isfield(param,'outer')
    param.outer = struct;
end

if ~isfield(param.outer,'linesearch')
    param.outer.linesearch = false;
end

if ~isfield(param.outer,'dispOnline')
    param.outer.dispOnline = false;
end

% Fixed-point approach for computing the hypergradient
if ~isfield(param.outer,'fixedPointHG')
    param.outer.fixedPointHG = true;
end

if ~isfield(param.outer,'stepsize')
    Lips = 0.003; 
    T = size(y.trn,2);
    param.outer.stepsize    = (1/(5*T*Lips))*1;
end
    
% Parameters of the model
param.outer.nTasks      = size(y.val,2);
param.outer.nFeatures   = size(X.val,2);
if ~isfield(param.outer,'nGroups')
    param.outer.nGroups   = param.outer.nFeatures;
end

% Variables
if param.outer.compObjective
    upperObjective = cell(1,param.outer.itermax_k);
end
if param.outer.savenormGroupOperator
    NormGroupOperator = cell(1,param.outer.itermax_k);
end
if param.outer.saveHyperGrad
    HyperGrad = cell(1,param.outer.itermax_k); 
end
if param.outer.saveLambda
    Lambda = cell(1,param.outer.itermax_k);
end
if param.outer.saveTheta
    Theta = cell(param.outer.itermax_k); 
end
if param.outer.saveTheta_dist
    Theta_dist = cell(1,param.outer.itermax_k);
end

%% Header needed for lower-level problem

if ~isfield(param,'inner')
    param.inner = struct;
end

% Saving iterates (needed if not using the fixed-point approach)
if ~isfield(param.inner,'saveIterates') && param.outer.fixedPointHG
    param.inner.saveIterates = false;
elseif ~param.outer.fixedPointHG
    param.inner.saveIterates = true;
end

% Compute objective
if ~isfield(param.inner,'compObjective')
    param.inner.compObjective = false;
end

% Number of iterations
if ~isfield(param.inner,'itermax')
    param.inner.itermax = 500;
end

% Parameters of the model
param.inner.eps         = EPS;
param.inner.nTasks      = size(y.trn,2); 
param.inner.nObs        = size(X.trn,1); 
param.inner.nFeatures   = size(X.trn,2); 
param.inner.nGroups     = param.outer.nGroups;

%% Main body

% Optimizers of the lower and upper problem 
opt_lower = optimGS_setting_penalty_lambda( param.inner );
opt_upper = optimBLGS_setting_penalty_lambda( opt_lower,param, param.inner ); 

eps_k = param.outer.eps_k; %initialization value epsilon parameter penalty term 
beta = param.outer.beta; %decreasing factor epsilon

% Initialization of the upper optimizer
[theta,hyperGrad_aux,lambda,hyperGrad_aux_lambda,plt] = opt_upper.initialize(); 

it_cond = 0; %iteration condition satisfied
c = 0.0001; %preconditioning lambda
for iter=1:param.outer.itermax_k %for loop eps_k 
    it_cond = it_cond +1; 

    outer_itermax_iter = param.outer.itermax(iter); %outer interations depend on for loop 

    if param.outer.compObjective
        upperObjective_tmp = NaN(1,outer_itermax_iter);
    end
    if param.outer.savenormGroupOperator
        NormGroupOperator_tmp = NaN(1,outer_itermax_iter);
    end
    if param.outer.saveHyperGrad
        HyperGrad_tmp = cell(1,outer_itermax_iter); 
    end
    if param.outer.saveLambda
        Lambda_tmp = NaN(1,outer_itermax_iter);
    end
    if param.outer.saveTheta
        Theta_tmp = NaN(size(thetastar,1),size(thetastar,2),outer_itermax_iter); 
    end
    if param.outer.saveTheta_dist
        Theta_dist_tmp = NaN(1,outer_itermax_iter);
    end
    
    for m=1:outer_itermax_iter
        
        %% Gradient step
        [hyperGrad,hyperGrad_aux,hyperGrad_lambda,hyperGrad_aux_lambda,upperObj,nGO] = opt_upper.hypergradient(y.trn,y.val,X.trn,X.val,theta,hyperGrad_aux,lambda,hyperGrad_aux_lambda,eps_k,m,iter_of);
        theta = opt_upper.proj_Theta( theta - param.outer.stepsize*hyperGrad);
	    lambda = opt_upper.proj_Lambda( lambda - param.outer.stepsize*c*hyperGrad_lambda); 

        % Objective & Misc [optimal]
        if param.outer.compObjective && (rem(m-1,iter_of)==0) 
            upperObjective_tmp(m) = upperObj;
            display(m)
            display(upperObj)
            display(lambda)
        end
        if param.outer.savenormGroupOperator
            NormGroupOperator_tmp(m) = nGO; 
        end
        if param.outer.saveHyperGrad
            HyperGrad_tmp{m} = {hyperGrad,hyperGrad_lambda}; 
        end
        if param.outer.saveLambda
            Lambda_tmp(m) = lambda; 
        end
        if param.outer.saveTheta
            Theta_tmp(:,:,m) = theta; 
        end
        if param.outer.saveTheta_dist
            Theta_dist_tmp(m) = norm(thetastar - theta,2);
        end
        if mod(m,param.misc.saveiter)==0
           save(strcat(param.misc.savename,'_iter',num2str(m),'.mat'));
        end

        % Display groups [optional]
        opt_upper.display.refresh(plt,theta)
    end

        if param.outer.compObjective
            upperObjective{iter} = upperObjective_tmp;
        end
        if param.outer.savenormGroupOperator
            NormGroupOperator{iter} = NormGroupOperator_tmp;
        end
        if param.outer.saveHyperGrad
            HyperGrad{iter} = HyperGrad_tmp; 
        end
        if param.outer.saveLambda
            Lambda{iter} = Lambda_tmp;
        end
        if param.outer.saveTheta
            Theta{iter} = Theta_tmp; 
        end
        if param.outer.saveTheta_dist
            Theta_dist{iter} = Theta_dist_tmp; 
        end        

        %Algorithm1 paper %check binary condition and decrease eps_k
        tol = 1e-2; %tollerance infinite norm 
    
        theta_0 = theta-0; %distance from 0
        theta_1 = 1-theta; %distance from 1
        theta_min = min(theta_0,theta_1); %minimum distance theta from 0 and 1 
        theta_min_inf = max(theta_min); %vecnorm(theta_min,inf) %infinite norm column-wise
        dist = max(theta_min_inf); %max/sum between infinite norm column  
        
        if dist >= tol 
            eps_k = beta*eps_k; 
        else
            break
        end
end

%% OUTPUT

if param.outer.compObjective
   otp.objective = upperObjective; 
end
if param.outer.compObjective
   otp.normgroupoperator = NormGroupOperator; 
end
if param.outer.saveHyperGrad
    otp.hypergrad = HyperGrad;
end
if param.outer.saveLambda
    otp.lambda = Lambda; 
end
if param.outer.saveTheta
    otp.theta = Theta; 
end
if param.outer.saveTheta_dist
    otp.theta_dist = Theta_dist; 
end

end

