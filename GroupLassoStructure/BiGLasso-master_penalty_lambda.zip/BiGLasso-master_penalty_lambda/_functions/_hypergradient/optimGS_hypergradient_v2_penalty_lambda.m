function [ b, beta  ] = optimGS_hypergradient_v2_penalty_lambda(yval,Xval, theta, lambda, opt, param, var) 

W_tensor = @(W,theta) reshape(repmat(W,[size(theta,2),1]),[size(W,1),size(theta,2),size(W,2)]);

function [otp_var] = prodCustom(var1,var2)
        otp_var = var1*var2;
end

function [otp_var] = p1_mathcalB_transp(var_a)
    prodvar = NaN(size(var_a));
    for ttt=1:size(yval,2)
        prodvar(:,ttt)     = prodCustom(var.nsd_mat(:,:,ttt),var_a(:,ttt));
    end
    otp_var     = -opt.opA(theta,W_tensor(prodvar,theta));
end

function [ otp_var ] = B1(var_a)
     [ otp_var] = p1_mathcalB_transp(var_a);
end

function [otp_var] = p2_mathcalB_transp(var_u,var_a)
    prodvar = NaN(size(var_a));
    for ttt=1:size(var_a,2)
        prodvar(:,ttt)     = prodCustom(var.nsd_mat(:,:,ttt),var_a(:,ttt));
    end
    otp_var     = -opt.opA(var_u,W_tensor(prodvar,var_u));
end

B2 = @(var_a)   p2_mathcalB_transp(var.u,var_a);

function [otp_var] = p2_mathcalA_transp(var_u,var_v,var_w,var_a)
    vartmp = NaN(size(var_v));
    for ttt=1:size(var_a,3)
        vartmp(:,:,ttt) = opt.nabla2_phi_star( var_v(:,:,ttt),var_a(:,:,ttt),lambda);
    end
    tmp = opt.opA( vartmp, W_tensor(var_w,vartmp) ); 
    otp_var = var.stepsize*p2_mathcalB_transp( var_u, squeeze(opt.opA_star(theta,vartmp)) ) + var.stepsize*tmp;
end

function [otp_var] = A2(var_a,iiter)
    [otp_var] = p2_mathcalA_transp(var.iterates.u(:,:,:,iiter), var.iterates.v(:,:,:,iiter), var.iterates.w(:,:,iiter), var_a);
end

function [otp_var] = p1_mathcalA_transp(var_u,var_v,var_a)
    vartmp = NaN(size(var_v));
    vartmp2 = NaN(size(var_v));
    for ttt=1:size(var_a,3)
        vartmp(:,:,ttt) = opt.nabla2_phi_star( var_v(:,:,ttt),var_a(:,:,ttt),lambda);
        vartmp2(:,:,ttt) = opt.nabla2_phi(var_u(:,:,ttt),vartmp(:,:,ttt),lambda);
    end
    otp_var = vartmp2 + var.stepsize*p1_mathcalB_transp( squeeze(opt.opA_star(theta,vartmp)) );        
end

function [otp_var] = A1(var_a,iiter)    
    [otp_var] = p1_mathcalA_transp(var.iterates.u(:,:,:,iiter), var.iterates.v(:,:,:,iiter), var_a);
end

function [otp_var] = A3(var_a,iiter)
    u = var.iterates.u(:,:,:,iiter);
    w = var.iterates.w(:,:,iiter); 
    den1 = opt.vartmp_den(u,lambda);
    add1 = (1./sqrt(den1)).*u;
    c = var.stepsize*opt.opA(theta,W_tensor(w,theta));
    v = add1 + c ;
    lambda_dv = -(lambda^2./(den1).^(3/2)).*u - c;
    sum_v_lambdadv = - (sum(u.^2,1)./(den1).^(3/2)).*u;
    den2 = 1 + sum(v.^2,1); 
    prod_v_lambda_dv = NaN(1,size(v,2),size(v,3));
    for ttt=1:size(v,3)
        prod_v_lambda_dv(:,:,ttt) = diag(v(:,:,ttt)'*lambda_dv(:,:,ttt))';
    end
    dA_lambda = sum_v_lambdadv ./sqrt(den2) - (prod_v_lambda_dv ./ (den2.^(3/2))) .* v; 
    [otp_var] = squeeze(sum(sum(dA_lambda.*var_a)));
end


w = var.w;
dCdw = NaN(size(w));
for tt=1:size(yval,2)
    dCdw(:,tt) = opt.dCdw(yval(:,tt),Xval(:,:,tt),w(:,tt));
end
[a] = B1(dCdw);
b = B2(dCdw);
beta = zeros(size(yval,2),1); 

for ii= param.inner.itermax:-1:1
    b = A2(a,ii) + b;
    beta = A3(a,ii) + beta; 
    [a] = A1(a,ii);
end

beta = beta';


end




