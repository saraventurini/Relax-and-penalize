
    addpath '\metrics'

    %save results 

    N = 20;          %Number of samples
    P = 100;          %Number of features
    L = 10;           %Number of groups

    %folders
    folder_name1 = "C:\Users\Sara\Desktop\Projects\PenaltyBilevel\BiGLasso-master_penalty\BiGLasso-master\synthesizeDataset";
    folder_name2 = "C:\Users\Sara\Desktop\Projects\PenaltyBilevel\BiGLasso-master\BiGLasso-master\Results_synthesizeDataset";   
    folder_name3 = "C:\Users\Sara\Desktop\Projects\PenaltyBilevel\BiGLasso-master_lambda\BiGLasso-master\Results_synthesizeDataset";
    folder_name4 = "C:\Users\Sara\Desktop\Projects\PenaltyBilevel\BiGLasso-master_lambda\BiGLasso-master\Plots_synthesizeDataset";
        
    targetFolder = fullfile(scriptPath, '..', 'your_folder_name');
    
    %parameters
    T = 500;         %Number of tasks 
    S = 1;           %Number of non-zero groups per task
    synth.groups.distrib = 'inequal';

    %metric
    %metrics = ['Acc_original','Acc_penalty','NMI_original','NMI_penalty'];
    Precision_original = [];
    Recall_original = [];
    Accuracy_original = [];
    Specificity_original = [];
    F1score_original = [];
    Jaccard_original = [];
    Precision_penalty = [];
    Recall_penalty = [];
    Accuracy_penalty = [];
    Specificity_penalty = [];
    F1score_penalty = [];
    Jaccard_penalty = [];

    sampl = 5; %10; %samples %number of synthetic datasets same parameters
    for it=1:sampl

        %load dataset
        file_name="synth_dataset_N"+num2str(N)+"_P"+num2str(P)+"_T"+num2str(T)+"_L"+num2str(L)+"_S"+num2str(S)+"_DIST"+synth.groups.distrib+"_"+num2str(it);
        file_name = fullfile(folder_name1,file_name); 
        load(file_name) %save(file_name,'N','P','T','L','S','synth','y','X','thetastar','wstar','Xwstar')
      
        [~,groupstar] = find(thetastar);
        n = length(groupstar);
    
        %original code
        file_name = "result_synth_dataset_N"+num2str(N)+"_P"+num2str(P)+"_T"+num2str(T)+"_L"+num2str(L)+"_S"+num2str(S)+"_DIST"+synth.groups.distrib+"_"+num2str(it)+"_SAGD";
        file_name = fullfile(folder_name2,file_name); 
        load(file_name) %save(file_name,'thetaHat','thetaHat_','otp','param')
   
        [row,col] = find(thetaHat);
        %if missing rows insert element in isolated groups
        if length(row)~=n
            row_missing = setdiff([1:100],row);
            row_missing_n = length(row_missing); 
            row = [row; row_missing'];
            col = [col; (max(col)+1 : max(col)+row_missing_n)'];
        end
        [~,sortIdx] = sort(row,'ascend');
        groupHat_original = col(sortIdx);
    
        %plot oracle solution
        figure(102);clf;
        subplot(131);
        imagesc(thetastar);
        xlabel('Groups','Interpreter','latex','fontsize',2)
        ylabel('Features','Interpreter','latex','fontsize',2)
        title('Oracle $\theta^*$','Interpreter','latex','fontsize',2)
        set(gca,'fontsize',15,'clim',[0 1])
        subplot(132);
        imagesc(thetaHat);
        xlabel('Groups','Interpreter','latex','fontsize',2)
        ylabel('Features','Interpreter','latex','fontsize',2)
        title('$\hat{\theta}$ with original','Interpreter','latex','fontsize',2)
        set(gca,'fontsize',15,'clim',[0 1])


        %original lambda
        file_name = "lambda_result_synth_dataset_N"+num2str(N)+"_P"+num2str(P)+"_T"+num2str(T)+"_L"+num2str(L)+"_S"+num2str(S)+"_DIST"+synth.groups.distrib+"_"+num2str(it)+"_SAGD_c0.001_box0.001";
        file_name = fullfile(folder_name3,file_name); 
        load(file_name); %save(file_name,'thetaHat','otp','it_cond','eps_k','param')

        [row,col] = find(thetaHat);
        %if missing rows insert element in isolated groups
        if length(row)~=n
            row_missing = setdiff([1:100],row);
            row_missing_n = length(row_missing); 
            row = [row; row_missing'];
            col = [col; (max(col)+1 : max(col)+row_missing_n)'];
        end
        [~,sortIdx] = sort(row,'ascend');
        groupHat_penalty = col(sortIdx);
    
        subplot(133);
        imagesc(thetaHat);
        xlabel('Groups','Interpreter','latex','fontsize',2)
        ylabel('Features','Interpreter','latex','fontsize',2)
        title('$\hat{\theta}$ with original lambda','Interpreter','latex','fontsize',2)
        set(gca,'fontsize',15,'clim',[0 1])
    
        %save plots
        file_name = "plot_result_synth_dataset_N"+num2str(N)+"_P"+num2str(P)+"_T"+num2str(T)+"_L"+num2str(L)+"_S"+num2str(S)+"_DIST"+synth.groups.distrib+"_"+num2str(it)+".png";
        file_name = fullfile(folder_name4,file_name); 
        saveas(gca,file_name)

        %clear P
        cm = confusion_matrix_ordered(groupstar,groupHat_original);
        [~,~,Accuracy,~,~,Jaccard] = multiclass_metrics_common(cm);
        Accuracy_original = [Accuracy_original Accuracy];

        Jaccard_original = [Jaccard_original Jaccard];

        cm = confusion_matrix_ordered(groupstar,groupHat_penalty);
        [~,~,Accuracy,~,~,Jaccard] = multiclass_metrics_common(cm);
        Accuracy_penalty = [Accuracy_penalty Accuracy];
        Jaccard_penalty = [Jaccard_penalty Jaccard];

    end


    %save metrics
    Accuracy_original = Accuracy_original';
    Jaccard_original = Jaccard_original';
    Accuracy_original_lambda = Accuracy_penalty';
    Jaccard_original_lambda = Jaccard_penalty';


    Tab=table(Accuracy_original,Accuracy_original_lambda,Jaccard_original,Jaccard_original_lambda); 
    file_name = "metrics_result_synth_dataset_N"+num2str(N)+"_P"+num2str(P)+"_T"+num2str(T)+"_L"+num2str(L)+"_S"+num2str(S)+"_DIST"+synth.groups.distrib+"_"+num2str(it)+".csv";
    file_name = fullfile(folder_name4,file_name); 
    writetable(Tab,file_name,'Delimiter',';'); %csv file

    