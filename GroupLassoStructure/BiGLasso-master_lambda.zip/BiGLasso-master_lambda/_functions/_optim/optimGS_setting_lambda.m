function [ opt ] = optimGS_setting_lambda( param )

rng(0)
digitsOld = digits(100);

EPS         = param.eps;

%% GROUPS

% // Linear operator (and its adjoint) defining the group structure
opt.opA         = @(var1,var2) var1.*var2; %var1 theta, var2 W_tensor
opt.opA_star    = @(var1,var2) sum(var1.*var2,2);

%% FIDELITY & REGULARIZER

% Functions defining the lower-level problem
l2fid                   = @(vary,varX,varw) .5*sum(sum((vary - squeeze(sum(bsxfun(@times,permute(varX,[2,1,3]),reshape(varw,size(varw,1),1,size(varw,2))),1))).^2));  
opt.fidelity            = @(y,X,w) l2fid(y,X,w);
opt.opA0                = @(y,X,w) 0;
opt.opA0_star           = @(y,X,t) 0;
opt.lipschitz           = @(theta,lambda) lambda/EPS; 
opt.NSD_mat             = @(y,X) inv(X'*X/length(y)+EPS*eye(size(X,2)));
opt.NSD_vec             = @(y,X) squeeze(sum(bsxfun(@times,X,reshape(y,size(y,1),1,size(y,2))),1))./size(y,1); 
opt.legendreFunction0   = 'void';
opt.dCdw                = @(yval,Xval,w) (Xval'*Xval*w - Xval'*yval)/length(yval);
opt.nabla_smooth_dual   = @(Mat,vec,var) Mat*(vec+var);    
opt.regularizer         = @(v,lambda) lambda*sum(sqrt(sum(v.^2,1))); 
opt.legendreFunction    = 'Hellinger-like';
opt.objective_primal    = @(y,X,w,v,lambda) opt.fidelity(y,X,w) + opt.regularizer(v,lambda) + .5*EPS*sum(w.^2); 

%% LEGENDRE FUNCTIONS
opt.nabla_phi       = @(varin,lambda) varin./(sqrt(lambda^2 - sum(varin.^2,1))); %MODIFIED
opt.nabla_phi_star  = @(varin,lambda) lambda*varin./sqrt(1+sum(varin.^2,1)); %MODIFIED
opt.nabla2_phi      = @(var1,var2,lambda) diag((var1'*var2))'.*var1./(lambda^2 - sum(var1.^2,1)).^(3/2) + var2./sqrt(lambda^2-sum(var1.^2,1)); %MODIFIED
opt.nabla2_phi_star = @(var1,var2,lambda) - lambda*(diag(var1'*var2))'.*var1./(1 + sum(var1.^2,1)).^(3/2) + lambda*var2./sqrt(1+sum(var1.^2,1));  %MODIFIED

opt.prox_Phi0       = @(varin,cst) 0;
opt.nabla_Phi0      = @(varin) 0;
opt.nabla_prox_Phi0 = @(var1,var2,cst) 0;
opt.nabla2_Phi0     = @(var1,var2) 0;

opt.vartmp_den = @(var1,lambda) lambda^2 - sum(var1.^2,1); 
 
end

