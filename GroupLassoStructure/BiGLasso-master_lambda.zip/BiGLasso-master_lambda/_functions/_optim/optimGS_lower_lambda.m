function [ w_tasks,output,normGroupOperator_val ] = optimGS_lower_lambda( y, X, theta, lambda, opt, param, iterr ) 

NSD_vec             = opt.NSD_vec(y,X);            
if size(y,2)==1
    NSD_vec = NSD_vec'; 
end
NSD_mat = NaN(size(X,2),size(X,2),size(y,2));
for tt=1:size(y,2)
    NSD_mat(:,:,tt) = opt.NSD_mat(y(:,tt),X(:,:,tt));
end
output.nsd_mat      = NSD_mat;      

%///// Step size (can be stored)
if ~isfield(param,'stepsize')
    lip = opt.lipschitz(theta,lambda);
    stepsize = .99/lip;
    normGroupOperator_val = param.eps/lambda*lip;
else
    assert(param.stepsize < 1/opt.lipschitz(y,X,theta),'Invalid stepsize');
    stepsize = param.stepsize;
end


w_tasks = NaN(size(theta,1),size(y,2));
v_tasks = NaN(size(theta,1),size(theta,2),size(y,2));
u_tasks = NaN(size(theta,1),size(theta,2),size(y,2));

w_iter = NaN(size(theta,1),size(y,2),param.itermax+1);
v_iter = NaN(size(theta,1),size(theta,2),size(y,2),param.itermax);
u_iter = NaN(size(theta,1),size(theta,2),size(y,2),param.itermax+1);

for tt=1:size(y,2)    

    %///// Initialization
    if ~isfield(param,'initialPoint')
        u = zeros(size(theta));
    else
        u   = param.initialPoint.u;
    end

    
    %///// Clear memory space
    f       = fieldnames(param);
    param   = rmfield(param,[f(~ismember(f,{'itermax','nGroups','compObjective','saveIterates'}))]);

    %% MAIN
    for iter = 1:param.itermax

    %%%%%%%%%%%%%%%%% Forward Backward Scheme %%%%%%%%%%%%%%%%%
    
        % Intermediate step: primal update
        w   = opt.nabla_smooth_dual(NSD_mat(:,:,tt),NSD_vec(:,tt),-opt.opA_star(theta,u));

        Aw  = opt.opA(theta,w);
        % Forward step
        v = stepsize*Aw;
        v = v + opt.nabla_phi(u,lambda);


        % Storing: iterates (verify location) 
        if param.saveIterates
            w_iter(:,tt,iter) = w;
            v_iter(:,:,tt,iter)  = v;
            u_iter(:,:,tt,iter)  = u;
        end

        % Backward step: dual update
        u = opt.nabla_phi_star(v,lambda); 

    
        %%%%%%%%%%%%%%%%%%% Storing and measures %%%%%%%%%%%%%%%%%%%
        
        % Primal objective
        if param.compObjective
            output.objective(iter) = opt.objective_primal(y(:,tt),X(:,:,tt),w,Aw,lambda); %MODIFIED
        end

    end

    w   = opt.nabla_smooth_dual(NSD_mat(:,:,tt),NSD_vec(:,tt),-opt.opA_star(theta,u));
    if param.saveIterates
        w_iter(:,tt,iter+1) = w;
        u_iter(:,:,tt,iter+1)  = u;
    end
    
    w_tasks(:,tt) = w;
    v_tasks(:,:,tt) = v;
    u_tasks(:,:,tt) = u;
         
end

% Storing: iterates (verify location) %MOVED
if param.saveIterates
    output.iterates.w     = w_iter;
    output.iterates.v     = v_iter;
    output.iterates.u     = u_iter;
end


%% OUTPUT
output.w        = w_tasks;
output.v        = v_tasks;
output.u        = u_tasks;
output.stepsize = stepsize;

end


