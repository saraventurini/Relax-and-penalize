function [ theta,lambda,otp  ] = BiGLasso_lambda( y,X,EPS, param , wstar , thetastar) 

format long

rng(0)
iter_of = param.outer.iter_of; 

otp = struct;

if ~isfield(param,'misc')
    param.misc = struct;
end

if ~isfield(param.misc,'saveiter')
    param.misc.saveiter = Inf;
end

%% Header needed for upper-level problem

if ~isfield(param,'outer')
    param.outer = struct;
end

if ~isfield(param.outer,'compObjective')
    param.outer.compObjective = false;
end

if ~isfield(param.outer,'linesearch')
    param.outer.linesearch = false;
end

if ~isfield(param.outer,'dispOnline')
    param.outer.dispOnline = true;
end

% Fixed-point approach for computing the hypergradient
if ~isfield(param.outer,'fixedPointHG')
    param.outer.fixedPointHG = true;
end

if ~isfield(param.outer,'stepsize')
    Lips = 0.003; 
    T = size(y.trn,2);
    param.outer.stepsize    = (1/(5*T*Lips))*1;
end
    
% Parameters of the model
param.outer.nTasks      = size(y.val,2); 
param.outer.nFeatures   = size(X.val,2);
if ~isfield(param.outer,'nGroups')
    param.outer.nGroups   = param.outer.nFeatures;
end

% Variables
if param.outer.compObjective
    upperObjective = NaN(1,param.outer.itermax);
end
if param.outer.savenormGroupOperator
    NormGroupOperator = NaN(1,param.outer.itermax);
end
if param.outer.saveHyperGrad
    HyperGrad = cell(1,param.outer.itermax); 
end
if param.outer.saveLambda
    Lambda = NaN(1,param.outer.itermax);
end
if param.outer.saveTheta
    Theta = NaN(size(thetastar,1),size(thetastar,2),param.outer.itermax); 
end
if param.outer.saveTheta_dist
    Theta_dist = NaN(1,param.outer.itermax);
end

%% Header needed for lower-level problem

if ~isfield(param,'inner')
    param.inner = struct;
end

% Saving iterates (needed if not using the fixed-point approach)
if ~isfield(param.inner,'saveIterates') && param.outer.fixedPointHG
    param.inner.saveIterates = false;
elseif ~param.outer.fixedPointHG
    param.inner.saveIterates = true;
end

% Compute objective
if ~isfield(param.inner,'compObjective')
    param.inner.compObjective = false;
end

% Number of iterations
if ~isfield(param.inner,'itermax')
    param.inner.itermax = 500;
end

% Parameters of the model
param.inner.eps         = EPS;
param.inner.nTasks      = size(y.trn,2); 
param.inner.nObs        = size(X.trn,1); 
param.inner.nFeatures   = size(X.trn,2); 
param.inner.nGroups     = param.outer.nGroups;


%% Main body

% Optimizers of the lower and upper problem 
opt_lower = optimGS_setting_lambda( param.inner );
opt_upper = optimBLGS_setting_lambda( opt_lower,param); 


% Initialization of the upper optimizer
[theta,hyperGrad_aux,lambda,hyperGrad_aux_lambda,plt] = opt_upper.initialize(); 

c = 0.0001; 

for iter=1:param.outer.itermax
    [hyperGrad,hyperGrad_aux,hyperGrad_lambda,hyperGrad_aux_lambda,upperObj,nGO] = opt_upper.hypergradient(y.trn,y.val,X.trn,X.val,theta,hyperGrad_aux,lambda,hyperGrad_aux_lambda,iter,iter_of); %MODIFIED
    theta = opt_upper.proj_Theta( theta - param.outer.stepsize*hyperGrad );
    lambda = opt_upper.proj_Lambda( lambda - param.outer.stepsize*c*hyperGrad_lambda ); 

    % Display groups [optional]
    opt_upper.display.refresh(plt,theta)
    
    % Objective & Misc [optimal]
    if param.outer.compObjective && (rem(iter-1,iter_of)==0) 
        upperObjective(iter) = upperObj; 
        display(iter)
        display(upperObj) 
        display(lambda)
    end
    if param.outer.savenormGroupOperator
        NormGroupOperator(iter) = nGO; 
    end
    if param.outer.saveHyperGrad
        HyperGrad{iter} = {hyperGrad,hyperGrad_lambda}; 
    end
    if param.outer.saveLambda
        Lambda(iter) = lambda; 
    end
    if param.outer.saveTheta
        Theta(:,:,iter) = theta; 
    end
    if param.outer.saveTheta_dist
        Theta_dist(iter) = norm(thetastar - theta,2); 
    end
    if mod(iter,param.misc.saveiter)==0
       save(strcat(param.misc.savename,'_iter',num2str(iter),'.mat'));
    end

end

%% OUTPUT

if param.outer.compObjective
   otp.objective = upperObjective; 
end
if param.outer.savenormGroupOperator
    otp.normGroupOperator = NormGroupOperator; 
end
if param.outer.saveHyperGrad
    otp.hypergrad = HyperGrad; 
end
if param.outer.saveLambda
    otp.lambda = Lambda; 
end
if param.outer.saveTheta
    otp.theta = Theta; 
end
if param.outer.saveTheta_dist
    otp.theta_dist = Theta_dist; 
end

end

