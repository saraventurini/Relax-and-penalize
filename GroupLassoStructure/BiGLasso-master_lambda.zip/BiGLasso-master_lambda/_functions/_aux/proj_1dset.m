function [ projy ] = proj_1dset( y, box )

lb = box(1);
ub = box(2);
projy = min(max(y,lb),ub);

end

