function [ valsup ] = normGroupOperator_(theta)
%exact calculation norm operator (not estimate)
    valsup = max(sum(theta.^2,2));
end