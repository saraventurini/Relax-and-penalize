%Function create confusion metrix ordered
%It is used to calculate accuracy, precision, recall
%INPUT: E vector expected communities
%       P vector predicted communities
%OUTPUT: T confusion metrix ordered
function [T] = confusion_matrix_ordered(E,P)

[T] = confusion_matrix(E,P); %confusion matrix
%T_save = T;

%ordered confusion matrix
index_sort = 0;
x_keep = (1:size(T,1))';
y_keep = (1:size(T,2))';

while index_sort~=size(T,1) && index_sort~=size(T,2)

    T_sub = T(index_sort+1:size(T,1),index_sort+1:size(T,2));
    M = max(max(T_sub)); %maximum value of T
    [x,y] = find(T_sub==M); %indices of M in T

    x = x(1); %use x(1) and y(1) because maybe more entries correspond to maximum value 
    y = y(1);
    
    if index_sort~=0
        x_sort = cat(1,(1:index_sort)',x+index_sort);
        y_sort = cat(1,(1:index_sort)',y+index_sort);
    else
        x_sort = x;
        y_sort = y;       
    end
    index_sort = index_sort + length(x); 
    
    x_keep = setdiff(x_keep,x_sort');
    y_keep = setdiff(y_keep,y_sort');

    x_keep = cat(1,x_sort,x_keep);
    y_keep = cat(1,y_sort,y_keep);
    
    T = T(x_keep,y_keep);

end
T = T'; %row real % column predicted

%{
%if T not square add zeros
if size(T,1)~=size(T,2)
    [size_max,dim_max] = max(size(T)); 
    if dim_max==1 %add columns
        T = [T, zeros(size_max,size_max-size(T,2))]; 
    else %add rows
        T = [T; zeros(size_max-size(T,1),size_max)']; 
    end
    
end
%}

end

%{
%multi-class accuracy, precision, recall
%https://www.evidentlyai.com/classification-metrics/multi-class-metrics
multiclass_metrics_common(T)
%}

